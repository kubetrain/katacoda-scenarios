Welcome to the stateless Siddhi App deployment scenario!
