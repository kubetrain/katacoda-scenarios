Welcome to the distributed stateful Siddhi App deployment with existing NATS scenario!
