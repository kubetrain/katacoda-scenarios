Welcome to the stateful Siddhi App deployment scenario!
