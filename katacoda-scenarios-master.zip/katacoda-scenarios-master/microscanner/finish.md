Congratulations, you've finished this scenario! Here's what you have covered:

- Scanning a container image for vulnerabilities with Microscanner
