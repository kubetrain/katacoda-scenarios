# Interactive Katacoda Scenarios

[![](http://shields.katacoda.com/katacoda/lizrice/count.svg)](https://www.katacoda.com/lizrice "Get your profile on Katacoda.com")

Visit https://www.katacoda.com/lizrice for a list of all the scenarios and courses included in this repo. 

If you would like to try writing a container in Go it is [here](https://www.katacoda.com/lizrice/scenarios/scratch).
