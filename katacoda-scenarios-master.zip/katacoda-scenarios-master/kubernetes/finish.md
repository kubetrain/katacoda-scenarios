Congratulations, you have run Go code under Kubernetes!
