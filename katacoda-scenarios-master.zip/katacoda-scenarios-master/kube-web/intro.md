In this scenario you'll run a Go application in a Kubernetes cluster that connects to a database service for storing state information. 

These exercises have been tests in the single node Kubernetes cluster that is set up for you here in Katacoda, but you should also be able to run the same exercises using the Kubernetes support in Docker for Mac/Windows on your laptop if you prefer.
