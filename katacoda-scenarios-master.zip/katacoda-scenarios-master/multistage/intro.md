In this scenario you'll learn how to compile your Go code as part of the image build step
