Well done! Now you can build your application into a small and efficient image with one build command.
