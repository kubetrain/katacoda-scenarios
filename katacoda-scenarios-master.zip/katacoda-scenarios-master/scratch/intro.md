In this lesson you'll get an introduction to what a container really is, by writing a basic container in Go. You'll see how a container is really just a Linux process, with a restricted view. 
