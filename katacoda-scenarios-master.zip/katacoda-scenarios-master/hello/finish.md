Congratulations, you've finished this scenario! Here's what you have covered:

- Building a container image from a Dockerfile 
- Running a container
- Network port mapping
