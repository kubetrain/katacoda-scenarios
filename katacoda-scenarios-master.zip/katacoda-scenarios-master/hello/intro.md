Welcome! In this lesson you will:

- Build and run a Go application as a container
- Write a Dockerfile to define how a container image gets built
- Run a container, instantiating what's in the container image
- See how a network port from the host's perspective can be mapped to a different port inside the container
