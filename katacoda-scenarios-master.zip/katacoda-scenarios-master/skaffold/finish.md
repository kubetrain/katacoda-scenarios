Congratulations, you've finished this scenario!

## Running on your laptop

If you would like to try running Skaffold on your laptop, you can install it as described in the [documentation](https://skaffold.dev/docs/getting-started/). 

