In this scenario you'll see how Skaffold helps when you're developing Go applications that will run in Kubernetes. 
