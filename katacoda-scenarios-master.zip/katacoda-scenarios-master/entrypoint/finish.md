Congratulations, you've got another scenario under your belt! You should now know the difference between ENTRYPOINT and CMD, and between the shell and exec form of commands in Dockerfiles. 
