In this scenario you will explore the different ways to determine what gets executed when you start a container, by defining the ENTRYPOINT and CMD commands in a Dockerfile. 
