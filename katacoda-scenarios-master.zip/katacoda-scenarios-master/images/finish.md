Congratulations, you've finished this scenario! Here's what you have covered:

- Building a container image containing additional files
- Mounting directories from the host into the container
- Stdout and stderr are accessible through the `docker logs` command
- Passing environment variables into containers

You have also seen how to use `docker ps -q` to get running container IDs that you can then pass in to other docker commands.

