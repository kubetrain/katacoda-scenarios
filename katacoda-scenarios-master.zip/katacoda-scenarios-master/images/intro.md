In this section you will dig into some more details of containers and container images

- What gets built into a container image
- Getting logs from containers
- Mounting host directories into containers
- Passing environment variables into the container
