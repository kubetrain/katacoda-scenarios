mkdir text
touch text/response